﻿namespace ProjetV1.Models
{
    public class Joueur
    {
        public string Nom {  get; set; }
        public int Nombre_but { get; set; }
        public int Nombre_passe { get; set; }
    }
}
