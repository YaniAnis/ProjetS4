﻿namespace ProjetV1.Models
{
    public class Stade
    {
        public int Id { get; set; }
        public string Nom {  get; set; }
        public int Capatite { get; set; }
    }
}
