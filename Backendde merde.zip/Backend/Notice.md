EN

The NuGet package used in this project are :
-Microsoft.AspNetCore.OpenApi
-Microsoft.EntityFrameworkCore
-Microsoft.EntityFrameworkCore.Tools
-Pomelo.EntityFrameworkCore.MySql
-Swashbuckle.AspNetCore

FR
Les package utiliser dans ce projet sont :
-Microsoft.AspNetCore.OpenApi
-Microsoft.EntityFrameworkCore
-Microsoft.EntityFrameworkCore.Tools
-Pomelo.EntityFrameworkCore.MySql
-Swashbuckle.AspNetCore
